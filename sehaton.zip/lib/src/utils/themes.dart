// lib/src/utils/themes.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class FontSizeProvider extends ChangeNotifier {
  double _scale = 1.0;
  double get scale => _scale;

  void increase() {
    _scale = (_scale + 0.1).clamp(1.0, 2.0);
    notifyListeners();
  }

  void decrease() {
    _scale = (_scale - 0.1).clamp(0.8, 2.0);
    notifyListeners();
  }
}

ThemeData sehatonTheme() {
  return ThemeData(
    primarySwatch: Colors.red,
    scaffoldBackgroundColor: Colors.white,
    textTheme: const TextTheme(
      bodyLarge: TextStyle(fontSize: 20),
      bodyMedium: TextStyle(fontSize: 18),
      titleLarge: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
        textStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      ),
    ),
  );
}
