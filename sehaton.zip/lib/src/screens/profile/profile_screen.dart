import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../home_screen.dart';
import '../family/family_menu_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;

  bool _loading = true;
  Map<String, dynamic>? _userData;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final user = _auth.currentUser;
    if (user == null) return;

    final doc = await _firestore.collection('users').doc(user.uid).get();
    if (doc.exists) {
      setState(() {
        _userData = doc.data();
        _loading = false;
      });
    } else {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil Saya'),
        backgroundColor: Colors.green,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _userData == null
              ? const Center(child: Text('Data profil tidak ditemukan.'))
              : Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ListView(
                    children: [
                      const CircleAvatar(
                        radius: 50,
                        backgroundImage:
                            AssetImage('assets/profile_placeholder.png'),
                      ),
                      const SizedBox(height: 16),
                      Center(
                        child: Text(
                          _userData!['name'] ?? 'Tanpa Nama',
                          style: const TextStyle(
                              fontSize: 22, fontWeight: FontWeight.bold),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Center(
                        child: Text(
                          _userData!['email'] ?? '-',
                          style: const TextStyle(color: Colors.grey),
                        ),
                      ),
                      const SizedBox(height: 20),
                      Card(
                        child: ListTile(
                          leading: const Icon(Icons.badge),
                          title: const Text('Peran'),
                          subtitle: Text(_userData!['role'] ?? '-'),
                        ),
                      ),
                      Card(
                        child: ListTile(
                          leading: const Icon(Icons.family_restroom),
                          title: const Text('Kode Keluarga'),
                          subtitle: Text(_userData!['familyCode'] ?? '-'),
                        ),
                      ),
                      Card(
                        child: ListTile(
                          leading: const Icon(Icons.verified_user),
                          title: const Text('Status Premium'),
                          subtitle: Text(
                            (_userData!['isPremium'] == true)
                                ? 'Aktif'
                                : 'Tidak Aktif',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
      bottomNavigationBar: _buildBottomBar(context),
    );
  }

  Widget _buildBottomBar(BuildContext context) {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      currentIndex: 4, // posisi menu profil
      selectedItemColor: Colors.green.shade700,
      unselectedItemColor: Colors.grey,
      onTap: (index) {
        switch (index) {
          case 0:
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const HomeScreen()),
            );
            break;
          case 3:
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const FamilyMenuScreen()),
            );
            break;
          case 4:
            // sudah di halaman profil, tidak perlu apa-apa
            break;
        }
      },
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Beranda"),
        BottomNavigationBarItem(
            icon: Icon(Icons.medical_services), label: "Obat"),
        BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today), label: "Janji"),
        BottomNavigationBarItem(
            icon: Icon(Icons.family_restroom), label: "Keluarga"),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profil"),
      ],
    );
  }
}
