import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FamilyScreen extends StatefulWidget {
  const FamilyScreen({Key? key}) : super(key: key);

  @override
  _FamilyScreenState createState() => _FamilyScreenState();
}

class _FamilyScreenState extends State<FamilyScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  String? _familyCode;
  String? _familyName;
  List<Map<String, dynamic>> _members = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadFamilyData();
  }

  Future<void> _loadFamilyData() async {
    setState(() => _isLoading = true);
    try {
      final user = _auth.currentUser;
      if (user == null) return;

      final userDoc = await _firestore.collection('users').doc(user.uid).get();
      if (!userDoc.exists) return;

      final data = userDoc.data();
      if (data == null) return;

      final familyCode = data['familyCode'];
      _familyCode = familyCode;
      _familyName = data['name'] ?? 'Keluarga Saya';

      if (familyCode != null && familyCode.toString().isNotEmpty) {
        final familyDoc =
            await _firestore.collection('families').doc(familyCode).get();
        if (familyDoc.exists) {
          final familyData = familyDoc.data()!;
          final memberIds = List<String>.from(familyData['members'] ?? []);

          final members = <Map<String, dynamic>>[];
          for (var id in memberIds) {
            final memberDoc =
                await _firestore.collection('users').doc(id).get();
            if (memberDoc.exists) {
              members.add({
                'name': memberDoc['name'] ?? 'Tanpa Nama',
                'email': memberDoc['email'] ?? '-',
                'role': memberDoc['role'] ?? '-',
              });
            }
          }

          setState(() {
            _members = members;
          });
        }
      }
    } catch (e) {
      debugPrint('Error load family: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _showAddMemberDialog() async {
    final TextEditingController nameController = TextEditingController();
    final TextEditingController emailController = TextEditingController();

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          title: const Text("Tambah Anggota Keluarga"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: "Nama Anggota",
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: emailController,
                decoration: const InputDecoration(
                  labelText: "Email Anggota",
                  prefixIcon: Icon(Icons.email),
                ),
                keyboardType: TextInputType.emailAddress,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Batal"),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              onPressed: () async {
                final name = nameController.text.trim();
                final email = emailController.text.trim().toLowerCase();

                if (name.isEmpty || email.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Nama dan email wajib diisi")),
                  );
                  return;
                }

                Navigator.pop(context);
                await _addMemberToFamily(name, email);
              },
              child: const Text("Tambah"),
            ),
          ],
        );
      },
    );
  }

  Future<void> _addMemberToFamily(String name, String email) async {
    try {
      final user = _auth.currentUser;
      if (user == null) return;

      final userDoc = await _firestore.collection('users').doc(user.uid).get();
      if (!userDoc.exists) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Data pengguna tidak ditemukan.")),
        );
        return;
      }

      final familyCode = userDoc['familyCode'];
      if (familyCode == null || familyCode.toString().isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Anda belum memiliki keluarga.")),
        );
        return;
      }

      // 🔍 Cek apakah user dengan email ini sudah ada
      final query = await _firestore
          .collection('users')
          .where('email', isEqualTo: email)
          .limit(1)
          .get();

      String memberId;

      if (query.docs.isNotEmpty) {
        // ✅ User sudah ada
        final memberDoc = query.docs.first;
        memberId = memberDoc.id;

        await _firestore.collection('users').doc(memberId).set({
          'familyCode': familyCode,
          'role': 'member',
          'updatedAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      } else {
        // 🚀 Buat user baru (pastikan konsisten format Firestore)
        final newMemberRef = _firestore.collection('users').doc();
        memberId = newMemberRef.id;

        await newMemberRef.set({
          'uid': memberId,
          'name': name,
          'email': email,
          'familyCode': familyCode,
          'role': 'member',
          'createdAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
          'isPremium': false,
          'premiumExpiry': null,
          'photoUrl': '',
          'parentId': user.uid,
          'currentFamilyId': '',
          'fcmTokens': [],
        });
      }

      // 🧩 Tambahkan ke daftar anggota keluarga
      await _firestore.collection('families').doc(familyCode).set({
        'members': FieldValue.arrayUnion([memberId]),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Anggota berhasil ditambahkan")),
      );

      await _loadFamilyData();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Gagal menambahkan anggota: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Keluarga Saya"),
        backgroundColor: Colors.green,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _familyCode == null
              ? const Center(
                  child: Text("Anda belum memiliki keluarga."),
                )
              : RefreshIndicator(
                  onRefresh: _loadFamilyData,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 3,
                        child: ListTile(
                          leading: const Icon(Icons.family_restroom,
                              color: Colors.green, size: 32),
                          title: Text(
                            _familyName ?? 'Keluarga Saya',
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 18),
                          ),
                          subtitle: Text("Kode Keluarga: $_familyCode"),
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        "Daftar Anggota:",
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 10),
                      if (_members.isEmpty)
                        const Text("Belum ada anggota keluarga."),
                      ..._members.map((m) {
                        return Card(
                          child: ListTile(
                            leading: const Icon(Icons.person),
                            title: Text(m['name']),
                            subtitle: Text(m['email']),
                            trailing: Text(m['role']),
                          ),
                        );
                      }),
                    ],
                  ),
                ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green,
        onPressed: _showAddMemberDialog,
        child: const Icon(Icons.person_add),
      ),
    );
  }
}
