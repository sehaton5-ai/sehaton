import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/auth_service.dart';
import '../home_screen.dart';
import 'family_screen.dart';
import '../profile/profile_screen.dart';

class FamilyMenuScreen extends StatefulWidget {
  const FamilyMenuScreen({super.key});

  @override
  State<FamilyMenuScreen> createState() => _FamilyMenuScreenState();
}

class _FamilyMenuScreenState extends State<FamilyMenuScreen> {
  final _auth = AuthService();
  final _firestore = FirebaseFirestore.instance;

  String familyName = "";
  String familyCode = "";
  String userRole = "";
  String userName = "";
  List<Map<String, dynamic>> members = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _loadFamilyData();
  }

  Future<void> _loadFamilyData() async {
    setState(() => loading = true);
    final user = await _auth.getCurrentUser();
    if (user == null) {
      setState(() => loading = false);
      return;
    }

    final userDoc = await _firestore.collection('users').doc(user.uid).get();
    if (!userDoc.exists) {
      setState(() => loading = false);
      return;
    }

    final userData = userDoc.data()!;
    final code = (userData['familyCode'] ?? '').toString();
    final role = (userData['role'] ?? 'parent').toString();

    if (code.isEmpty) {
      setState(() {
        familyCode = "";
        familyName = "";
        userRole = role;
        userName = userData['name'] ?? user.displayName ?? '';
        members = [];
        loading = false;
      });
      return;
    }

    final familyDoc = await _firestore.collection('families').doc(code).get();
    if (!familyDoc.exists) {
      setState(() {
        familyCode = "";
        familyName = "";
        userRole = role;
        userName = userData['name'] ?? user.displayName ?? '';
        members = [];
        loading = false;
      });
      return;
    }

    final data = familyDoc.data()!;
    final List<dynamic> memberIds = data['members'] ?? [];

    final List<Map<String, dynamic>> memberDetails = [];
    for (var uid in memberIds) {
      final memberSnap = await _firestore.collection('users').doc(uid).get();
      if (memberSnap.exists) {
        final md = memberSnap.data()!;
        memberDetails.add({
          'name': md['name'] ?? 'Tanpa Nama',
          'email': md['email'] ?? '',
          'role': md['role'] ?? 'member'
        });
      }
    }

    setState(() {
      familyName = data['familyName'] ?? '';
      familyCode = data['familyCode'] ?? code;
      userRole = role;
      userName = userData['name'] ?? user.displayName ?? '';
      members = memberDetails;
      loading = false;
    });
  }

  // ---------------------------
  // Create Family
  // ---------------------------
  Future<void> _showCreateFamilyDialog() async {
    final TextEditingController nameController = TextEditingController();

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Text('Buat Keluarga Baru'),
        content: TextField(
          controller: nameController,
          decoration: const InputDecoration(
            labelText: 'Nama Keluarga',
            hintText: 'Contoh: Keluarga Budi',
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green.shade700),
            onPressed: () async {
              final name = nameController.text.trim();
              if (name.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Nama keluarga wajib diisi")));
                return;
              }
              Navigator.pop(context);
              await _createFamily(name);
            },
            child: const Text('Buat'),
          ),
        ],
      ),
    );
  }

  Future<void> _createFamily(String name) async {
    try {
      final user = await _auth.getCurrentUser();
      if (user == null) return;

      final code = DateTime.now().millisecondsSinceEpoch.toString();
      final now = DateTime.now().toIso8601String();

      await _firestore.collection('families').doc(code).set({
        'familyName': name,
        'familyCode': code,
        'createdBy': user.uid,
        'createdAt': now,
        'updatedAt': now,
        'members': [user.uid],
      });

      await _firestore.collection('users').doc(user.uid).update({
        'familyCode': code,
        'role': 'parent',
        'updatedAt': now,
      });

      // reload data lokal
      await _loadFamilyData();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Keluarga berhasil dibuat")));
      }
    } catch (e) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Gagal membuat keluarga: $e")));
    }
  }

  // ---------------------------
  // Join Family
  // ---------------------------
  Future<void> _showJoinFamilyDialog() async {
    final TextEditingController codeController = TextEditingController();

    List<Map<String, dynamic>> searchResults = [];

    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setStateDialog) {
        Future<void> _searchFamilies(String q) async {
          final query = q.trim().toLowerCase();
          if (query.isEmpty) {
            setStateDialog(() => searchResults = []);
            return;
          }
          final snap = await _firestore.collection('families').get();
          final results = <Map<String, dynamic>>[];
          for (var doc in snap.docs) {
            final d = doc.data();
            final fname = (d['familyName'] ?? '').toString().toLowerCase();
            final fcode = (d['familyCode'] ?? '').toString().toLowerCase();
            if (fname.contains(query) || fcode.contains(query)) {
              results.add({
                'id': doc.id,
                'familyName': d['familyName'],
                'familyCode': d['familyCode']
              });
            }
          }
          setStateDialog(() => searchResults = results);
        }

        return AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          title: const Text('Gabung Keluarga'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: codeController,
                decoration: const InputDecoration(
                  labelText: 'Cari berdasarkan nama atau kode keluarga',
                  prefixIcon: Icon(Icons.search),
                ),
                onChanged: (v) => _searchFamilies(v),
              ),
              const SizedBox(height: 12),
              if (searchResults.isEmpty)
                const Text('Ketik untuk mencari keluarga...')
              else
                SizedBox(
                  height: 200,
                  child: ListView.builder(
                    itemCount: searchResults.length,
                    itemBuilder: (context, idx) {
                      final item = searchResults[idx];
                      return ListTile(
                        title: Text(item['familyName'] ?? '-'),
                        subtitle: Text('Kode: ${item['familyCode'] ?? '-'}'),
                        trailing: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green.shade700),
                          onPressed: () async {
                            final code = item['familyCode'] ?? item['id'];
                            Navigator.pop(context);
                            await _joinFamily(code.toString());
                          },
                          child: const Text('Gabung'),
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Tutup')),
          ],
        );
      }),
    );
  }

  Future<void> _joinFamily(String code) async {
    try {
      final user = await _auth.getCurrentUser();
      if (user == null) return;

      final familyRef = _firestore.collection('families').doc(code);
      final familySnap = await familyRef.get();
      if (!familySnap.exists) {
        if (mounted)
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("Kode keluarga tidak ditemukan")));
        return;
      }

      final membersList = List<String>.from(familySnap['members'] ?? []);
      if (!membersList.contains(user.uid)) membersList.add(user.uid);

      final now = DateTime.now().toIso8601String();
      await familyRef.update({'members': membersList, 'updatedAt': now});

      await _firestore
          .collection('users')
          .doc(user.uid)
          .update({'familyCode': code, 'role': 'member', 'updatedAt': now});

      await _loadFamilyData();

      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Berhasil bergabung ke keluarga")));
    } catch (e) {
      if (mounted)
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text("Gagal bergabung: $e")));
    }
  }

  // ---------------------------
  // Add Member (Nama + Email)
  // ---------------------------
  Future<void> _addMemberDialog() async {
    // Jangan tampilkan dialog jika role bukan 'parent'
    if (userRole != 'parent') {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("Hanya orang tua yang bisa menambah anggota")));
      return;
    }

    final TextEditingController nameController = TextEditingController();
    final TextEditingController emailController = TextEditingController();

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Text("Tambah Anggota Keluarga"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
                controller: nameController,
                decoration: const InputDecoration(
                    labelText: 'Nama Anggota', prefixIcon: Icon(Icons.person))),
            const SizedBox(height: 8),
            TextField(
                controller: emailController,
                decoration: const InputDecoration(
                    labelText: 'Email Anggota', prefixIcon: Icon(Icons.email)),
                keyboardType: TextInputType.emailAddress),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green.shade700),
            onPressed: () async {
              final name = nameController.text.trim();
              final emailRaw = emailController.text.trim();
              final email = emailRaw.toLowerCase();
              if (name.isEmpty || email.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    content: Text("Nama dan email wajib diisi.")));
                return;
              }

              // ensure user has session
              final currentUser = await _auth.getCurrentUser();
              if (currentUser == null) return;

              Navigator.pop(context);
              await _addOrCreateMember(name, email);
            },
            child: const Text('Tambah'),
          ),
        ],
      ),
    );
  }

  Future<void> _addOrCreateMember(String name, String email) async {
    try {
      // ensure familyCode available
      if (familyCode.isEmpty) {
        if (mounted)
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text(
                  "Family code tidak ditemukan. Buat keluarga terlebih dahulu.")));
        return;
      }

      final q = await _firestore
          .collection('users')
          .where('email', isEqualTo: email)
          .limit(1)
          .get();

      String memberId;
      final now = DateTime.now().toIso8601String();

      if (q.docs.isNotEmpty) {
        memberId = q.docs.first.id;
        await _firestore.collection('users').doc(memberId).update(
            {'familyCode': familyCode, 'role': 'member', 'updatedAt': now});
      } else {
        final newRef = await _firestore.collection('users').add({
          'name': name,
          'email': email,
          'familyCode': familyCode,
          'role': 'member',
          'createdAt': now,
          'updatedAt': now
        });
        memberId = newRef.id;
      }

      await _firestore.collection('families').doc(familyCode).update({
        'members': FieldValue.arrayUnion([memberId]),
        'updatedAt': now
      });

      await _loadFamilyData();

      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Anggota '$name' berhasil ditambahkan.")));
    } catch (e) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Gagal menambahkan anggota: $e")));
    }
  }

  // ---------------------------
  // Leave Family (untuk member)
  // ---------------------------
  Future<void> _leaveFamily() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Konfirmasi'),
        content:
            const Text('Apakah Anda yakin ingin keluar dari keluarga ini?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Ya, Keluar'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      final user = await _auth.getCurrentUser();
      if (user == null) return;

      // Hapus dari families.members
      await _firestore.collection('families').doc(familyCode).update({
        'members': FieldValue.arrayRemove([user.uid]),
        'updatedAt': DateTime.now().toIso8601String(),
      });

      // Reset data user
      await _firestore.collection('users').doc(user.uid).update({
        'familyCode': '',
        'role': 'parent',
        'updatedAt': DateTime.now().toIso8601String(),
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Anda telah keluar dari keluarga')),
        );
        await _loadFamilyData();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal keluar dari keluarga: $e')),
        );
      }
    }
  }

  // ---------------------------
  // Build
  // ---------------------------
  @override
  Widget build(BuildContext context) {
    if (loading)
      return const Scaffold(body: Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(
        title: Text(familyName.isNotEmpty ? familyName : "Keluarga Saya"),
        backgroundColor: Colors.green.shade700,
        actions: [
          IconButton(
            icon: const Icon(Icons.home),
            tooltip: "Beranda",
            onPressed: () {
              Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: (_) => const HomeScreen()));
            },
          ),
          IconButton(
              icon: const Icon(Icons.refresh), onPressed: _loadFamilyData),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: familyCode.isEmpty ? _buildNoFamilyView() : _buildFamilyView(),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: 3,
        selectedItemColor: Colors.green.shade700,
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pop(context);
              break;
            case 3:
              break;
          }
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Beranda"),
          BottomNavigationBarItem(
              icon: Icon(Icons.medical_services), label: "Obat"),
          BottomNavigationBarItem(
              icon: Icon(Icons.calendar_today), label: "Janji"),
          BottomNavigationBarItem(
              icon: Icon(Icons.family_restroom), label: "Keluarga"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profil"),
        ],
      ),
    );
  }

  Widget _buildNoFamilyView() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.family_restroom, size: 100, color: Colors.grey),
          const SizedBox(height: 16),
          const Text("Anda belum tergabung dalam keluarga."),
          const SizedBox(height: 8),
          const Text(
              "Silakan buat keluarga baru atau bergabung ke keluarga yang sudah ada."),
          const SizedBox(height: 20),
          if (userRole == 'parent')
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade700),
              icon: const Icon(Icons.add),
              label: const Text("Buat Keluarga"),
              onPressed: _showCreateFamilyDialog,
            ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green.shade700),
            icon: const Icon(Icons.link),
            label: const Text("Gabung Keluarga"),
            onPressed: _showJoinFamilyDialog,
          ),
        ],
      ),
    );
  }

  Widget _buildFamilyView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("Kode Keluarga: $familyCode",
            style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const Text("Anggota Keluarga:",
            style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Expanded(
          child: members.isEmpty
              ? const Center(child: Text("Belum ada anggota keluarga."))
              : ListView.builder(
                  itemCount: members.length,
                  itemBuilder: (context, idx) {
                    final m = members[idx];
                    return Card(
                      child: ListTile(
                        leading: const Icon(Icons.person),
                        title: Text(m['name']),
                        subtitle: Text("${m['email']} (${m['role']})"),
                      ),
                    );
                  },
                ),
        ),
        if (userRole == 'parent')
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: ElevatedButton.icon(
              icon: const Icon(Icons.person_add),
              label: const Text("Tambah Anggota"),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade700,
                  minimumSize: const Size.fromHeight(50)),
              onPressed: _addMemberDialog,
            ),
          ),
      ],
    );
  }

  // ✅ tambahan baru untuk navigasi bawah
  Widget _buildBottomBar(BuildContext context) {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      currentIndex: 3, // posisi menu keluarga
      selectedItemColor: Colors.green.shade700,
      unselectedItemColor: Colors.grey,
      onTap: (index) {
        switch (index) {
          case 0:
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const HomeScreen()),
            );
            break;
          case 3:
            // sudah di halaman keluarga
            break;
          case 4:
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const ProfileScreen()),
            );
            break;
        }
      },
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Beranda"),
        BottomNavigationBarItem(
            icon: Icon(Icons.medical_services), label: "Obat"),
        BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today), label: "Janji"),
        BottomNavigationBarItem(
            icon: Icon(Icons.family_restroom), label: "Keluarga"),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profil"),
      ],
    );
  }
}
