import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/auth_service.dart';

class FamilyScreen extends StatefulWidget {
  final String mode; // "create" | "join" | "view"
  const FamilyScreen({super.key, required this.mode});

  @override
  State<FamilyScreen> createState() => _FamilyScreenState();
}

class _FamilyScreenState extends State<FamilyScreen> {
  final _auth = AuthService();
  final _firestore = FirebaseFirestore.instance;

  final TextEditingController _familyNameController = TextEditingController();
  final TextEditingController _joinCodeController = TextEditingController();

  bool _loading = false;
  Map<String, dynamic>? _familyData;
  String _role = "member";
  String _familyCode = "";

  @override
  void initState() {
    super.initState();
    if (widget.mode == "view") {
      _loadFamilyData();
    }
  }

  /// 🔹 Muat data keluarga untuk menu "Keluarga"
  Future<void> _loadFamilyData() async {
    final user = await _auth.getCurrentUser();
    if (user == null) return;

    final userDoc = await _firestore.collection('users').doc(user.uid).get();
    if (!userDoc.exists) return;

    final code = userDoc['familyCode'] ?? "";
    if (code.isEmpty) return;

    final familyDoc = await _firestore.collection('families').doc(code).get();
    if (!familyDoc.exists) return;

    final data = familyDoc.data()!;
    setState(() {
      _familyData = data;
      _familyCode = code;
      _role = data['createdBy'] == user.uid ? "parent" : "member";
    });
  }

  /// 🔹 Membuat keluarga baru
  Future<void> _createFamily() async {
    final name = _familyNameController.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Nama keluarga tidak boleh kosong.")),
      );
      return;
    }

    setState(() => _loading = true);
    final user = await _auth.getCurrentUser();
    if (user == null) return;

    try {
      final familyCode = DateTime.now().millisecondsSinceEpoch.toString();
      await _firestore.collection('families').doc(familyCode).set({
        'familyName': name,
        'familyCode': familyCode,
        'createdBy': user.uid,
        'members': [user.uid],
        'createdAt': DateTime.now().toIso8601String(),
        'updatedAt': DateTime.now().toIso8601String(),
      });

      await _firestore.collection('users').doc(user.uid).update({
        'familyCode': familyCode,
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Keluarga '$name' berhasil dibuat!")),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Gagal membuat keluarga: $e")),
      );
    } finally {
      setState(() => _loading = false);
    }
  }

  /// 🔹 Gabung ke keluarga
  Future<void> _joinFamily() async {
    final code = _joinCodeController.text.trim();
    if (code.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Kode keluarga tidak boleh kosong.")),
      );
      return;
    }

    setState(() => _loading = true);
    final user = await _auth.getCurrentUser();
    if (user == null) return;

    try {
      final doc = await _firestore.collection('families').doc(code).get();
      if (!doc.exists) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Keluarga tidak ditemukan.")),
        );
        setState(() => _loading = false);
        return;
      }

      await _firestore.collection('families').doc(code).update({
        'members': FieldValue.arrayUnion([user.uid]),
        'updatedAt': DateTime.now().toIso8601String(),
      });

      await _firestore.collection('users').doc(user.uid).update({
        'familyCode': code,
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Berhasil bergabung dengan keluarga!")),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Gagal bergabung: $e")),
      );
    } finally {
      setState(() => _loading = false);
    }
  }

  /// 🔹 Keluar dari keluarga
  Future<void> _leaveFamily() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Text("Keluar dari Keluarga"),
        content: const Text(
            "Apakah Anda yakin ingin keluar dari keluarga ini? Anda bisa membuat atau bergabung kembali nanti."),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text("Batal")),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Keluar"),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    final user = await _auth.getCurrentUser();
    if (user == null) return;

    await _firestore.collection('users').doc(user.uid).update({
      'familyCode': "",
    });

    if (_familyCode.isNotEmpty) {
      await _firestore.collection('families').doc(_familyCode).update({
        'members': FieldValue.arrayRemove([user.uid]),
      });
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Anda telah keluar dari keluarga.")),
      );
      Navigator.pop(context);
    }
  }

  /// 🔹 Daftar keluarga yang bisa dipilih
  Widget _buildAvailableFamilies() {
    return StreamBuilder<QuerySnapshot>(
      stream: _firestore.collection('families').snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Text("Belum ada keluarga yang terdaftar.");
        }

        final families = snapshot.data!.docs;

        return Column(
          children: families.map((doc) {
            final data = doc.data() as Map<String, dynamic>;
            final familyName = data['familyName'] ?? '-';
            final familyCode = data['familyCode'] ?? '';
            return Card(
              child: ListTile(
                title: Text(familyName),
                subtitle: Text("Kode: $familyCode"),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                onTap: () {
                  _joinCodeController.text = familyCode;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text("Kode keluarga $familyName dimasukkan."),
                      backgroundColor: Colors.green,
                      duration: const Duration(seconds: 1),
                    ),
                  );
                },
              ),
            );
          }).toList(),
        );
      },
    );
  }

  /// 🔹 Tampilan daftar anggota keluarga
  Widget _buildFamilyMembers() {
    final members = _familyData?['members'] ?? [];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Anggota Keluarga:",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 10),
        ...members.map<Widget>((uid) {
          return FutureBuilder<DocumentSnapshot>(
            future: _firestore.collection('users').doc(uid).get(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const SizedBox();
              final user = snapshot.data!.data() as Map<String, dynamic>?;
              final name = user?['name'] ?? "Tidak diketahui";
              return ListTile(
                leading: const Icon(Icons.person),
                title: Text(name),
                subtitle: Text(
                    uid == _familyData?['createdBy'] ? "👑 Parent" : "Member"),
                trailing: _role == "parent" && uid != _familyData?['createdBy']
                    ? IconButton(
                        icon:
                            const Icon(Icons.remove_circle, color: Colors.red),
                        onPressed: () async {
                          await _firestore
                              .collection('families')
                              .doc(_familyCode)
                              .update({
                            'members': FieldValue.arrayRemove([uid]),
                          });
                          setState(() {});
                        },
                      )
                    : null,
              );
            },
          );
        }).toList(),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final isCreate = widget.mode == 'create';
    final isJoin = widget.mode == 'join';
    final isView = widget.mode == 'view';

    if (isView && _familyData != null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text("Keluarga Saya"),
          backgroundColor: const Color(0xFF388E3C),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Nama Keluarga: ${_familyData!['familyName']}",
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold)),
                Text("Kode: $_familyCode"),
                const SizedBox(height: 20),
                _buildFamilyMembers(),
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  onPressed: _leaveFamily,
                  icon: const Icon(Icons.logout),
                  label: const Text("Keluar dari Keluarga"),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(isCreate ? "Buat Keluarga Baru" : "Gabung Keluarga"),
        backgroundColor: const Color(0xFF388E3C),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Text(
                isCreate
                    ? "Masukkan nama keluarga Anda:"
                    : "Masukkan kode keluarga:",
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 10),
              TextField(
                controller:
                    isCreate ? _familyNameController : _joinCodeController,
                decoration: InputDecoration(
                  hintText: isCreate
                      ? "contoh: Keluarga Santoso"
                      : "contoh: 1730052891",
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 20),
              _loading
                  ? const CircularProgressIndicator()
                  : ElevatedButton.icon(
                      onPressed: isCreate ? _createFamily : _joinFamily,
                      icon: Icon(isCreate ? Icons.add : Icons.login),
                      label: Text(isCreate ? "Buat Keluarga" : "Gabung"),
                    ),
              if (isJoin) ...[
                const SizedBox(height: 30),
                const Divider(),
                const SizedBox(height: 10),
                const Text("Daftar Keluarga yang Tersedia",
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                _buildAvailableFamilies(),
              ]
            ],
          ),
        ),
      ),
    );
  }
}
