// lib/src/services/auth_service.dart
import 'dart:math';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  /// 🔹 Login / Register via Google
  Future<UserCredential?> signInWithGoogle() async {
    try {
      // 1️⃣ Login Google
      final googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return null;

      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final userCred = await _auth.signInWithCredential(credential);
      final user = userCred.user!;
      final firestore = FirebaseFirestore.instance;
      final users = firestore.collection('users');

      // 2️⃣ Cek apakah email sudah ada di Firestore
      final checkUser =
          await users.where('email', isEqualTo: user.email).limit(1).get();

      if (checkUser.docs.isEmpty) {
        // 🆕 User baru → otomatis parent
        final String newFamilyCode = _generateFamilyCode();

        await users.doc(user.uid).set({
          'uid': user.uid,
          'email': user.email,
          'name': user.displayName ?? '',
          'photoUrl': user.photoURL ?? '',
          'createdAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
          'role': 'parent',
          'isPremium': false,
          'premiumExpiry': null,
          'parentId': '',
          'familyCode': newFamilyCode,
          'currentFamilyId': '',
          'fcmTokens': [],
        });

        // 🔔 Notifikasi user baru
        _showLoginMessage(
          "Selamat datang, Anda terdaftar sebagai parent baru.",
          Colors.green,
        );
      } else {
        // 🔹 User lama → login sesuai role
        final data = checkUser.docs.first.data();
        final role = data['role'] ?? 'parent';

        // Update data dasar tanpa ubah role/email/familyCode
        await users.doc(checkUser.docs.first.id).set({
          'name': user.displayName ?? data['name'] ?? '',
          'photoUrl': user.photoURL ?? data['photoUrl'] ?? '',
          'updatedAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));

        // 🔔 Notifikasi sesuai role
        _showLoginMessage(
          role == 'member'
              ? "Selamat datang kembali, Anda login sebagai member."
              : "Selamat datang kembali, Anda login sebagai parent.",
          Colors.blueAccent,
        );
      }

      return userCred;
    } catch (e) {
      print("🔥 Error during Google Sign-In: $e");
      _showLoginMessage("Login gagal: $e", Colors.red);
      return null;
    }
  }

  /// 🔹 Fungsi tampilkan notifikasi global (tanpa ubah parameter)
  void _showLoginMessage(String message, Color color) {
    final context = navigatorKey.currentContext;
    if (context != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: color,
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  /// 🔹 Generate kode keluarga unik
  String _generateFamilyCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final rand = Random();
    return List.generate(6, (i) => chars[rand.nextInt(chars.length)]).join();
  }

  /// 🔹 Ambil user aktif
  Future<User?> getCurrentUser() async {
    return _auth.currentUser;
  }

  /// 🔹 Logout
  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
  }
}

/// 🔹 Global navigator key supaya _showLoginMessage bisa akses context
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
