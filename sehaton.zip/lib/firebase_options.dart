import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return const FirebaseOptions(
      apiKey: "AIzaSyCXfsGOk_MLeTkqIVBpCaBklBhZTRxIQ-E",
      authDomain: "sehaton-app.firebaseapp.com",
      projectId: "sehaton-app",
      storageBucket: "sehaton-app.firebasestorage.app",
      messagingSenderId: "1089401681273",
      appId: "1:1089401681273:web:648ef99494910b218faba8",
      measurementId: "G-ELPQLHVQML",
    );
  }
}
