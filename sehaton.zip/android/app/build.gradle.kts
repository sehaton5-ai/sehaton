// App-level build.gradle untuk SehatOn
// ------------------------------------
// Letakkan di: android/app/build.gradle
// ------------------------------------

apply plugin: 'com.android.application'
apply plugin: 'com.google.gms.google-services'
apply plugin: 'org.jetbrains.kotlin.android'

android {
    namespace "com.sehaton.app"
    compileSdk 34

    defaultConfig {
        applicationId "com.sehaton.app"
        minSdk 23
        targetSdk 34
        versionCode 1
        versionName "1.0.0"
        multiDexEnabled true
    }

    buildTypes {
        release {
            minifyEnabled false
            shrinkResources false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
        debug {
            minifyEnabled false
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding true
    }
}

dependencies {
    implementation platform('com.google.firebase:firebase-bom:33.4.0')

    implementation 'com.google.firebase:firebase-analytics'
    implementation 'com.google.firebase:firebase-auth'
    implementation 'com.google.firebase:firebase-firestore'
    implementation 'com.google.firebase:firebase-messaging'
    implementation 'com.google.firebase:firebase-storage'

    implementation 'com.google.android.gms:play-services-auth:21.1.0'
    implementation 'androidx.multidex:multidex:2.0.1'
}
