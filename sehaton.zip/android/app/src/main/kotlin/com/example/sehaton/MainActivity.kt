package com.example.sehaton

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
